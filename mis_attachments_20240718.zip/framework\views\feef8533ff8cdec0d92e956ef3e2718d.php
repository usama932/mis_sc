<?php if (isset($component)) { $__componentOriginal7d4adf92a073eb6c2876d9110358a4e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d4adf92a073eb6c2876d9110358a4e2 = $attributes; } ?>
<?php $component = App\View\Components\NformLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nform-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NformLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 
    <?php $__env->startSection('title'); ?>
        Add QBs Details and Action Points Details
    <?php $__env->stopSection(); ?>
    
    <div class="card">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <input type="hidden" id="qb_id" value="<?php echo e($qb->id); ?>" />
        <div class="container-fluid">
            <ul class="nav nav-tabs mt-1 fs-6">
                <li class="nav-item">
                    <a class="nav-link <?php if(session('active') == 'basic_info'): ?>  active <?php endif; ?>" data-bs-toggle="tab" href="#basic_info">Summary</a>
                </li>
             
                <li class="nav-item">
                    <a class="nav-link <?php if(session('active') == 'monitor_visit'): ?> active <?php else: ?>  <?php endif; ?>" data-bs-toggle="tab" href="#monitor_visit" > <?php if($qb->qb_base_monitoring == 1): ?> QBs Not Fully Met <?php else: ?> Add Observations <?php endif; ?></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if(session('active') == 'action_point'): ?> active <?php else: ?>  <?php endif; ?>" data-bs-toggle="tab" href="#action_point" >Action Point Details</a>
                </li>
              
                <li class="nav-item">
                    <a class="nav-link <?php if(session('active') == 'qbattachment'): ?> active <?php else: ?>  <?php endif; ?>" data-bs-toggle="tab" href="#qbattachment" >Comments and Attachment</a>
                </li>
            </ul>
        </div>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show <?php if(session('active') == 'basic_info'): ?> active <?php else: ?>  <?php endif; ?>" id="basic_info" role="tabpanel">
                <div>
                    <?php echo $__env->make('admin.quality_bench.basic_information.basic_information', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
           
            <div class="tab-pane fade show <?php if(session('active') == 'monitor_visit'): ?> active <?php else: ?>  <?php endif; ?>" id="monitor_visit" role="tabpanel" >
                <div>
                    <?php echo $__env->make('admin.quality_bench.monitor_visits.monitor_visits', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="tab-pane fade show <?php if(session('active') == 'action_point'): ?> active <?php else: ?>  <?php endif; ?>" id="action_point" role="tabpanel" >   
                <div>
                    <?php echo $__env->make('admin.quality_bench.action_point.action_point', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="tab-pane fade show <?php if(session('active') == 'qbattachment'): ?> active <?php else: ?>  <?php endif; ?>" id="qbattachment" role="tabpanel">
                <div>
                    <?php echo $__env->make('admin.quality_bench.qb_attachment.attachment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $("#qbformDiv").hide();
            $("#general_obsform").hide();
            $("#qbtableDiv").show();
            $("#qb_action_point_form").hide();
            $("#actionpointtableDiv").show();
          
            $('#date_visit').flatpickr({
                altInput: true,
                dateFormat: "Y-m-d",
                maxDate: new Date().fp_incr(+0),
                minDate: new Date("2023-10-01"),
            });
        </script>
     
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d4adf92a073eb6c2876d9110358a4e2)): ?>
<?php $attributes = $__attributesOriginal7d4adf92a073eb6c2876d9110358a4e2; ?>
<?php unset($__attributesOriginal7d4adf92a073eb6c2876d9110358a4e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d4adf92a073eb6c2876d9110358a4e2)): ?>
<?php $component = $__componentOriginal7d4adf92a073eb6c2876d9110358a4e2; ?>
<?php unset($__componentOriginal7d4adf92a073eb6c2876d9110358a4e2); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\mis_sc\resources\views/admin/quality_bench/edit.blade.php ENDPATH**/ ?>