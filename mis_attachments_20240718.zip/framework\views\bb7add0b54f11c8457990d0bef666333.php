<?php if (isset($component)) { $__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e = $attributes; } ?>
<?php $component = App\View\Components\DefaultLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('default-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DefaultLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', 'Monitoring Visits List'); ?>
   
    <div id="kt_app_content" class="app-content flex-column-fluid">
    
        <?php echo $__env->make('admin.quality_bench.partials.index_tiles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card mb-4">
            <?php echo $__env->make('admin.quality_bench.partials.filter_qb_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
       
        <div class="card">
            <div class="card-body pt-3">
                <div class="card-toolbar mb-2 d-flex justify-content-end">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create quality benchmarks')): ?>
                        <a href="<?php echo e(route('quality-benchs.create')); ?>" class="btn btn-sm btn-primary font-weight-bolder mx-2">
                            <span class="svg-icon svg-icon-primary svg-icon-1x mx-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                        <rect fill="#FFFFFF" x="4" y="11" width="16" height="2" rx="1"/>
                                        <rect fill="#FFFFFF" opacity="0.3" transform="translate(12.000000, 12.000000) rotate(-270.000000) translate(-12.000000, -12.000000)" x="4" y="11" width="16" height="2" rx="1"/>
                                    </g>
                                </svg>
                            </span>
                            Add Monitor Visit
                        </a>
                    <?php endif; ?>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped table-bordered nowrap" id="quality_bench" style="width:100%">
                        <thead>
                            <tr>
                                <th>#QB.No</th>
                                <th>Project</th>
                                <th>Partner</th>
                                <th>Province</th>
                                <th>District</th>
                                <th>Theme</th>
                                <th>Activity</th>
                                <th>GeoLocations</th>
                                <th>Staff Organization</th>
                                <th>Date Visit</th>
                                <th class="fs-8">QB Base Monitoring</th>
                                <th>Total QBs</th>
                                <th>QBs Not Fully Met</th>
                                <th>QBs Fully Met</th>
                                <th>QBs Not Applicable</th>
                                <th>Score Out</th>
                                <th>QBs Status</th>
                                <th>Attachment</th>
                                <th>Created At</th>
                                <th>Created By</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Table rows will be dynamically populated -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e)): ?>
<?php $attributes = $__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e; ?>
<?php unset($__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e)): ?>
<?php $component = $__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e; ?>
<?php unset($__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\mis_sc\resources\views/admin/quality_bench/index.blade.php ENDPATH**/ ?>