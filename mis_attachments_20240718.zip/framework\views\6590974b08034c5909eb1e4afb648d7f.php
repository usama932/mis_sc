<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" <?php echo printHtmlAttributes('html'); ?>>
<!--begin::Head-->
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>MIS - <?php echo $__env->yieldContent('title', 'MIS-SCP'); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/media/logos/favicon.ico')); ?>">

    <?php if(Auth::check()): ?>
     <?php echo includeFonts(); ?>

    <?php endif; ?>
  
    <?php $__currentLoopData = getGlobalAssets('css'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo sprintf('<link rel="stylesheet" href="%s">', asset($path)); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 

    <?php if(Auth::check()): ?>
    <?php $__currentLoopData = getVendors('css'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo sprintf('<link rel="stylesheet" href="%s">', asset($path)); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <!--end::Vendor Stylesheets-->

    <?php if(Auth::check()): ?>
        <?php $__currentLoopData = getCustomCss(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo sprintf('<link rel="stylesheet" href="%s">', asset($path)); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <!--end::Custom Stylesheets-->
    <?php if(Auth::check()): ?>
     <?php echo \Livewire\Livewire::styles(); ?>

    <?php endif; ?>
    <style>
        .dataTables_length, .dt-buttons {
            display: inline-block;
            vertical-align: middle;
        }
        .dataTables_wrapper .dataTables_length {
            float: left;
        }
        .dataTables_wrapper .dt-buttons {
            float: right;
            margin-left: 20px;
        }
    </style>
</head>
<!--end::Head-->

<!--begin::Body-->

<body class="app-default " id="kt_app_body" data-kt-name="metronic" data-kt-app-layout="light-sidebar" data-kt-app-header-fixed="true" data-kt-app-sidebar-enabled="true" data-kt-app-sidebar-fixed="true" data-kt-app-sidebar-hoverable="true" data-kt-app-sidebar-push-header="true" data-kt-app-sidebar-push-toolbar="true" data-kt-app-sidebar-push-footer="true" data-kt-app-toolbar-enabled="true">

<?php echo $__env->make('partials/theme-mode/_init', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldPushContent('stylesheets'); ?>

<?php echo $__env->yieldContent('content'); ?>


<?php $__currentLoopData = getGlobalAssets(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo sprintf('<script src="%s"></script>', asset($path)); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!--end::Global Javascript Bundle-->


<?php $__currentLoopData = getVendors('js'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php echo sprintf('<script src="%s"></script>', asset($path)); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = getCustomJs(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo sprintf('<script src="%s"></script>', asset($path)); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->yieldPushContent('scripts'); ?>
<!--end::Javascript-->

<?php if(Auth::check()): ?>
<script>
    $(document).ready(function () {
        $('#update_province').change(function () {
            var selectedProvince = $(this).val();

            // Make AJAX request
            $.ajax({
                "url":"<?php echo e(route('update_province')); ?>",
                "type":"POST",
                data: {
                    province: selectedProvince,
                    _token: '<?php echo csrf_token() ?>' // Include CSRF token for security
                },
                success: function (response) {
                    location.reload();
                    console.log(response);
                    // Handle success response here
                },
                error: function (error) {
                    console.log(error);
                    // Handle error here
                }
            });
        });
    });
</script>

<script>
    document.addEventListener('livewire:load', () => {
        Livewire.on('success', (message) => {
            toastr.success(message);
        });
        Livewire.on('error', (message) => {
            toastr.error(message);
        });

        Livewire.on('swal', (message, icon, confirmButtonText) => {
            if (typeof icon === 'undefined') {
                icon = 'success';
            }
            if (typeof confirmButtonText === 'undefined') {
                confirmButtonText = 'Ok, got it!';
            }
            Swal.fire({
                text: message,
                icon: icon,
                buttonsStyling: false,
                confirmButtonText: confirmButtonText,
                customClass: {
                    confirmButton: 'btn btn-primary'
                }
            });
        });
    });
</script>
<!-- Include Pusher JS library -->
<script src="https://js.pusher.com/7.0/pusher.min.js"></script>

<!-- Include Laravel Echo library -->
<script src="https://cdn.jsdelivr.net/npm/laravel-echo@1.10.0/dist/echo.iife.js"></script>

<!-- Include Axios library -->
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

<!-- Include CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<!-- Initialize Echo -->
<script>
    Pusher.logToConsole = true;

    const pusher = new Pusher('<?php echo e(env('PUSHER_APP_KEY')); ?>', {
        cluster: '<?php echo e(env('PUSHER_APP_CLUSTER')); ?>',
        encrypted: true,
        forceTLS: true,
        authEndpoint: '/broadcasting/auth', // Default Laravel Broadcasting authentication endpoint
        auth: {
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        }
    });

    window.Echo = new Echo({
        broadcaster: 'pusher',
        client: pusher,
        encrypted: true
    });

    window.Echo.private('App.Models.User.' + '<?php echo e(auth()->id()); ?>')
        .listen('activity-deadline', (data) => {
            console.log('Received activity-deadline event:', data);
            if (data.message) {
                const notificationItem = `
                    <div class="d-flex flex-stack py-4">
                        <div class="d-flex align-items-center">
                            <!--begin::Symbol-->
                            <div class="symbol symbol-35px me-4">
                                <span class="symbol-label bg-light-primary"><?php echo getIcon('abstract-28', 'fs-2 text-primary'); ?></span>
                            </div>
                            <!--end::Symbol-->
                            <!--begin::Title-->
                            <div class="mb-0 me-2">
                                <a href="#" class="fs-6 text-gray-800 text-hover-primary fw-bold">${data.title || 'Notification'}</a>
                                <div class="text-gray-400 fs-7">${data.message}</div>
                            </div>
                            <!--end::Title-->
                        </div>
                        <span class="badge badge-light fs-8">${data.time || 'Just now'}</span>
                    </div>
                `;
                document.getElementById('notification-list').insertAdjacentHTML('afterbegin', notificationItem);
            }
        })
        .error((error) => {
            console.error('Subscription error:', error);
        });
</script>

<?php echo \Livewire\Livewire::scripts(); ?>


<?php endif; ?>
</body>
<!--end::Body-->

</html>
<?php /**PATH C:\xampp\htdocs\mis_sc\resources\views/layout/master.blade.php ENDPATH**/ ?>