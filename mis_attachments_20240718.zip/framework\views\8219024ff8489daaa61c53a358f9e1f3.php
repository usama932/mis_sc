<div>
    <div class="">
        
    </div>
    <form class="form p-5" id="qb_attachment_form"  novalidate="novalidate" action="<?php echo e(route('attachments.store')); ?>" method="post" enctype="multipart/form-data">
        
        <?php echo csrf_field(); ?>
        <input type="hidden" name="quality_bench_id" value="<?php echo e($qb->id); ?>">
        <div class="card-body py-4">
            <div class="row">
                <input type="hidden" value="<?php echo e($qb_attachment->id ?? ''); ?>" name="id" >
                <input type="hidden" name="submit" value="0">
                <div class="fv-row col-md-12 mt-3">
                    <label class="fs-6 fw-semibold form-label mb-2">
                        <span class="">Comments</span>
                    </label>
                    <textarea class="form-control " placeholder="How does the score from this visit compare to previous visits? Have any of these QBs been “not fully met” for two or more visits?" row="2"  name="comments" / required><?php echo e($qb_attachment->comments ?? ''); ?></textarea>
                </div>
                <div class="fv-row col-md-12 mt-3">
                    <?php if(!empty($qb_attachment->document) && $qb_attachment->document != ''): ?>
                        <label class="fs-6 fw-semibold form-label mb-2">
                            <span class="required">ReUpload Attachment</span>
                        </label>
                    <?php else: ?>
                        <label class="fs-6 fw-semibold form-label mb-2 ">
                            <span class="required">Upload Attachment</span>
                        </label>
                    <?php endif; ?>
                    <div class="input-group">
                     
                        
                        <?php if(!empty($qb_attachment->document) && $qb_attachment->document != ''): ?>
                        <input type="file" name="document" class="form-control mx-4" value="<?php echo e($qb_attachment->document); ?>"  accept=".pdf">
                            <div class="input-group-append">
                                <a class="btn  btn-danger" title="Download Attachment" href="<?php echo e(route('showPDF.qb_attachments', $qb_attachment->id)); ?>" target="_blank">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-pdf" viewBox="0 0 16 16">
                                        <!-- SVG path code -->
                                    </svg> Download Attachment
                                </a>
                            </div>
                        <?php else: ?>
                        <input name="document" class="form-control upload_file_input" id="upload_file_input" accept="application/pdf" type="file" autocomplete="off" value="">
                        
                        <?php endif; ?>
                    </div>          
                </div>     
            </div>
        
        
            </div>
            <div class="d-flex justify-content-end pt-5">
                
              
                <button type="submit" class="btn btn-primary btn-sm mx-3 kt_attachment_submit">
                 
                    <?php echo $__env->make('partials/general/_button-indicator', ['label' => 'Submit'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </button>
               
            </div>
        </div>
    </form>
    
    
</div><?php /**PATH C:\xampp\htdocs\mis_sc\resources\views/admin/quality_bench/qb_attachment/attachment.blade.php ENDPATH**/ ?>