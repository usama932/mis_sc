
<?php /**PATH C:\xampp\htdocs\mis_sc\resources\views/layout/partials/sidebar-layout/sidebar/_footer.blade.php ENDPATH**/ ?>