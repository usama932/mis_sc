<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read dip')): ?>
    <div class="card menu menu-sub menu-sub-dropdown menu-column w-350px w-lg-375px" data-kt-menu="true" id="kt_menu_notifications">
        <h4 class="card-header mt-4">Notifications:</h4>
        <div class="tab-content">
            <div class="scroll-y  my-5 px-8" id="notification-list">
                
            </div>
        </div>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\mis_sc\resources\views/partials/menus/_notifications-menu.blade.php ENDPATH**/ ?>