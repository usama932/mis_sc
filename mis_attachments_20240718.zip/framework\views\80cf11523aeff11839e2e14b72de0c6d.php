
<div>
    <?php if($qb->qb_base_monitoring == 1): ?>
    <div class="alert alert-warning d-flex align-items-center p-5 mt-10 mb-5 me-20 ms-10">
        <i class="ki-duotone ki-shield-tick fs-2hx text-warning me-4"><span class="path1"></span><span class="path2"></span></i>                    
        <div class="d-flex flex-column">
            <h4 class="mb-1 text-warning">QBs Not Fully Met</h4>
            <span>This Monitoring Visit has <?php echo e($qb->qbs_not_fully_met ?? ''); ?> Not Fully met QBs.</span>
        </div>
    </div>
	<?php endif; ?>
	<!--end::Alert-->
    <form  class="form" id="qb_update_form"  novalidate="novalidate" action="<?php echo e(route('quality-benchs.update',$qb->id)); ?>" method="post">
       
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <div class="card-body py-4">
        <div class="row">
            <div class="fv-row col-md-6">
                <label class="fs-6 fw-semibold form-label mb-2">
                    <span class="required">Project</span>
                </label>
                <select name="project_name" id="project_name" aria-label="Select a Project Name" data-control="select2" data-placeholder="Select a Theme" class="form-select">
                    <option value="">Select Project</option>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($project->id); ?>" <?php if($qb->project_name == $project->id): ?> selected <?php endif; ?>><?php echo e($project->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div id="project_nameError" class="error-message "></div>
            </div>
            <div class="fv-row col-md-3">
                <label class="fs-6 fw-semibold form-label mb-2 d-flex">
                    <span class="required">Project Type</span>
                    <span class="spinner-border spinner-border-sm align-middle ms-2" id="projectloader"></span>
                </label>
                <input type="text" name="project_type" id="project_type" class="form-control" value="<?php echo e($qb->project_type ?? ''); ?>" />
               
                <div id="project_typeError" class="error-message "></div>
            </div>
            <div class="fv-row col-sm-3 col-md-3 col-lg-3">
                <label class="fs-6 fw-semibold form-label mb-2">
                    <span class="required">Partner</span>
                    
                </label>
                <select   name="partner" id="partner" aria-label="Select a Partner Name" data-control="select2" data-placeholder="Select a Partner" class="form-select">
                    <option value="">Select Partner Name</option>
                    <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($partner->id); ?>"  <?php if($qb->partner == $partner->id): ?> selected <?php endif; ?>><?php echo e($partner->slug); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </select>
                <div id="partnerError" class="error-message "></div>
            </div>
        </div>
        <div class="row mt-3">
            <div class="fv-row col-md-3">
                <label class="fs-6 fw-semibold form-label mb-2">
                    <span class="required">Province</span>
                </label>
                <select   name="province" id="kt_select2_province" aria-label="Select a Province" data-control="select2" data-placeholder="Select a Province..." class="form-select ">
                    <?php if(auth()->user()->permissions_level == 'province-wide' || auth()->user()->permissions_level == 'district-wide'): ?>
                        <option value="">Select Province</option>
                        
                        <option <?php if(auth()->user()->province == '4'): ?> selected <?php endif; ?> value='4'>Sindh</option>
                        <option  <?php if(auth()->user()->province == '2'): ?> selected <?php endif; ?> value='2'>KPK</option>
                        <option   <?php if(auth()->user()->province == '3'): ?> selected <?php endif; ?> value='3'>Balochistan</option>
                    <?php else: ?>
                        <option value="">Select Province</option>
                        
                        <option <?php if($qb->province == '4'): ?> selected <?php endif; ?> value='4'>Sindh</option>
                        <option  <?php if($qb->province == '2'): ?> selected <?php endif; ?> value='2'>KPK</option>
                        <option   <?php if($qb->province == '3'): ?> selected <?php endif; ?> value='3'>Balochistan</option>
                    <?php endif; ?>
                </select>
                <div id="kt_select2_provinceError" class="error-message "></div>
            </div>
            <div class="fv-row col-md-3">
                <label class="fs-6 fw-semibold form-label mb-2 d-flex">
                    <span class="required">District</span>
                    <span class="spinner-border spinner-border-sm align-middle ms-2" id="districtloader"></span>
                </label>
                <select id="kt_select2_district" name="district" aria-label="Select a District" data-control="select2" data-placeholder="Select a District..." class="form-select">
                    <option value="<?php echo e($qb->district); ?>"><?php echo e($qb->districts?->district_name ?? $frm->district); ?></option>
                </select>
                <div id="kt_select2_districtError" class="error-message "></div>
            </div>
            <div class="fv-row col-md-3">
                <label class="fs-6 fw-semibold form-label mb-2 d-flex">
                    <span class="required">Tehsil</span>
                    <span class="spinner-border spinner-border-sm align-middle ms-2" id="tehsilloader"></span>
                </label>
                <select id="kt_select2_tehsil" name="tehsil" aria-label="Select a Tehsil" data-control="select2" data-placeholder="Select a Tehsil..." class="form-select ">
                    <?php if(!empty($qb->tehsil)): ?>
                        <option value="<?php echo e($qb->tehsil); ?>"><?php echo e($qb->tehsils?->tehsil_name ?? $qb->tehsil); ?></option>
                    <?php endif; ?>
                </select>
                <div id="kt_select2_tehsilError" class="error-message "></div>
            </div>
            <div class="fv-row col-md-3">
                <label class="fs-6 fw-semibold form-label mb-2 d-flex">
                    <span class="required">UC</span>
                    <span class="spinner-border spinner-border-sm align-middle ms-2" id="ucloader"></span>
                </label>
                <select id="kt_select2_union_counsil" name="union_counsil" aria-label="Select a UC" data-control="select2" data-placeholder="Select a Uc..." class="form-select">
                    <?php if(!empty($qb->union_counsil)): ?>
                        <option value="<?php echo e($qb->union_counsil); ?>"><?php echo e($qb->uc?->uc_name ?? $frm->union_counsil); ?></option>
                    <?php endif; ?>
                </select>
                <div id="kt_select2_union_counsilError" class="error-message "></div>
            </div>
        </div>
        <div class="row mt-3">
            <div class="fv-row col-md-3">
                <label class="fs-6 fw-semibold form-label mb-2">
                    <span class="required">Village</span>
                </label>
                <input class="form-control" id="vilage" placeholder="Enter Village" name="village" value="<?php echo e($qb->village ?? ''); ?>">
                <div id="villageError" class="error-message "></div>
            </div>
            <div class="fv-row col-sm-3 col-md-3 col-lg-3">
                <label class="fs-6 fw-semibold form-label mb-2">
                    <span class="required">Theme</span>
                </label>
                <select name="theme" id="theme" aria-label="Select a Theme" data-control="select2" data-placeholder="Select a Theme" class="form-select">
                    <option value="">Select Theme</option>
                    <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($theme->id); ?>" <?php if($qb->theme == $theme->id): ?> selected <?php endif; ?> ><?php echo e($theme->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div id="themeError" class="error-message"></div>
            </div>
            <div class="fv-row col-md-3">
                <label class="fs-6 fw-semibold form-label mb-2">
                    <span class="required">Type of visit</span>
                </label>
                <select   name="type_of_visit" id="type_of_visit"  aria-label="Select a Type of Visit " data-control="select2" data-placeholder="Select a Type of Visit" class="form-select">
                    <option value="">Select Project Type</option>
                    <option value="Independent" <?php if($qb->type_of_visit == "Independent"): ?> selected <?php endif; ?>>Independent</option>
                    <option value="Joint" <?php if($qb->type_of_visit == "Joint"): ?> selected <?php endif; ?>>Joint</option>
                </select>
                <div id="type_of_visitError" class="error-message "></div>
            </div>
            <div class="fv-row col-md-3">
                <label class="fs-6 fw-semibold form-label mb-2">
                    <span class="required">Accompanied By</span>
                </label>
                <select name="accompanied_by" id="accompanied_by" aria-label="Select a Registrar Name" data-control="select2" data-placeholder="Select a Accompanied By..." class="form-select">
                    <option value="">Select Option</option>
                    <option value="Project Staff" <?php if($qb->accompanied_by == "Project Staff"): ?> selected <?php endif; ?>>Project Staff</option>
                    <option value="Govt Officials" <?php if($qb->accompanied_by == "Govt Officials"): ?> selected <?php endif; ?>>Govt Officials</option>
                    <option  value="Donor" <?php if($qb->accompanied_by == "Donor"): ?> selected <?php endif; ?>>Donor</option>
                    <option  value="NA" <?php if($qb->accompanied_by == "NA"): ?> selected <?php endif; ?>>NA</option>
                </select>
                <div id="accompanied_byError" class="error-message"></div>
            </div>
           
        </div>
        <div class="row mt-3">
            <div class="fv-row col-md-3">
                <label class="fs-6 fw-semibold form-label mb-2">
                    <span class="required">Monitoring Type</span>
                </label>
                <select   name="monitoring_type" id="monitoring_type"  aria-label="Select a Type of Visit " data-control="select2" data-placeholder="Select a Monitoring Type" class="form-select">
                    <option value="">Select Monitoring Type</option>
                    <option value="Process and output monitoring"  <?php if($qb->monitoring_type == "Process and output monitoring"): ?> selected <?php endif; ?>>Process and output monitoring</option>
                    <option value="Distribution" <?php if($qb->monitoring_type == "Distribution"): ?> selected <?php endif; ?>>Distribution</option>
                    <option value="Joint outcome monitoring" <?php if($qb->monitoring_type == "Joint outcome monitoring"): ?> selected <?php endif; ?>>Joint outcome monitoring</option>
                </select>
                <div id="monitoring_typeError" class="error-message"></div>
            </div>
         
            <div class="fv-row col-md-6">
                <label class="fs-6 fw-semibold form-label mb-2">
                    <span class="required">Activity visited</span>
                </label>
                <textarea  rows="1" class="form-control" id="activity_description"  name="activity_description"><?php echo e($qb->activity_description ?? ''); ?></textarea>
                <div id="activity_descriptionError" class="error-message"></div>
            </div>
            <?php if($qb->qb_base_monitoring == 1): ?>
                <div class="fv-row col-sm-1 col-md-1 col-lg-1">
                    <label class="fs-9 fw-semibold form-label mb-2">
                        <span class="required">Total QBs</span>
                    </label>
                    <input type="text" class="form-control fs-9" id="total_qbs"  name="total_qbs" value="<?php echo e($qb->total_qbs ?? ''); ?>">
                    <div id="total_qbsError" class="error-message"></div>
                </div>
                <div class="fv-row col-md-1">
                    <label class="fs-9 fw-semibold form-label mb-2">
                        <span class="required">Fully Met</span>
                    </label>
                    <input type="text" class="form-control fs-9" id="qbs_fully_met" name="qbs_fully_met" value="<?php echo e($qb->qbs_fully_met ?? ''); ?>">
                    <div id="qbs_fully_metError" class="error-message"></div>
                </div>
                <div class="fv-row col-md-1">
                    <label class="fs-9 fw-semibold form-label mb-2">
                        <span class="required">Not Applicable</span>
                    </label>
                    <input type="text" class="form-control fs-9" name="qb_not_applicable" id="qb_not_applicable" value="<?php echo e($qb->qb_not_applicable ?? ''); ?>">
                    <div id="qb_not_applicableError" class="error-message"></div>
                </div>
           
        
            <?php endif; ?>
        </div>
        <div class="row mt-3">
            <div class="fv-row col-md-3">
                <label class="fs-6 fw-semibold form-label mb-2">
                    <span class="required">Date of monitoring visit</span>
                </label>
                <input type="text" name="date_visit" id="date_visit" placeholder="Select date"  class="form-control" onkeydown="event.preventDefault()" data-provide="datepicker" value="<?php echo e(date('Y-m-d', strtotime($qb->date_visit ?? ''))); ?>">
                <div id="date_visitError" class="error-message"></div>
            </div>
            <div class="fv-row col-sm-3 col-md-3 col-lg-3">
                <label class="fs-6 fw-semibold form-label mb-2">
                    <span class="required">Visited By</span>
                </label>
                <input type="text" class="form-control" id="qb_filledby"  name="qb_filledby" value="<?php echo e($qb->qb_filledby ?? ''); ?>">
              
                <div id="qb_filledbyError" class="error-message"></div>
            </div>
            <div class="fv-row col-md-3">
                <label class="fs-6 fw-semibold form-label mb-2">
                    <span class="required">Staff Organization</span>
                </label>
                <select name="staff_organization" id="staff_organization" aria-label="Select a Visit Staff Name" data-control="select2" data-placeholder="Select a Registrar Name..." class="form-select" >
                    <option  value=""  <?php if($qb->staff_organization == "" ): ?> selected <?php endif; ?>>Select Option</option>
                    <option  value="SC Staff"  <?php if($qb->staff_organization == "SC Staff" ): ?> selected <?php endif; ?> >SC Staff</option>
                    <option  value="SRSP Staff" <?php if($qb->staff_organization == "SRSP Staff" ): ?> selected <?php endif; ?>>SRSP Staff</option>
                    <option  value="LRF Staff" <?php if($qb->staff_organization == "LRF Staff" ): ?> selected <?php endif; ?> >LRF Staff</option>
                    <option  value="TKF Staff" <?php if($qb->staff_organization == "TKF Staff" ): ?> selected <?php endif; ?> >TKF Staff</option>
                </select>
                <div id="staff_organizationError" class="error-message"></div>
            </div>

        </div>
        <div class="separator my-3"></div>
        <div class="text-end">
            <button type="submit" id="kt_qb_update_submit" class="btn btn-primary">
                <?php echo $__env->make('partials/general/_button-indicator', ['label' => 'Update'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </button>
            
        </div>
    </div>
    </form>
</div><?php /**PATH C:\xampp\htdocs\mis_sc\resources\views/admin/quality_bench/basic_information/basic_information.blade.php ENDPATH**/ ?>