<?php if (isset($component)) { $__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e = $attributes; } ?>
<?php $component = App\View\Components\DefaultLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('default-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DefaultLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title'); ?>
    Add/Edit Project Details
    <?php $__env->stopSection(); ?> 
    <style>
    .spacer::after {
            content: "\2002"; /* Unicode character for en space */
}
    </style>
    <div id="kt_app_content" class="app-content flex-column-fluid">

        <div class="card mb-4">
            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'administrator')): ?>
                <div class="accordion" id="accordionExample">
                    <div class="accordion-item">
                        <h3 class="accordion-header" id="headingOne">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                <div class="d-flex align-items-center">
                                    <!--begin::Symbol-->
                                    <div class="symbol symbol-50px me-5">
                                        <span class="symbol-label bg-light-danger">
                                            <i class="ki-duotone ki-filter-search fs-2x text-danger">
                                                <span class="path1"></span>
                                                <span class="path2"></span>
                                            </i>
                                        </span>
                                    </div>
                                    <!--end::Symbol-->
                                    <!--begin::Text-->
                                    <div class="d-flex flex-column">
                                        <a href="javascript:;" class="text-dark text-hover-primary fs-6 fw-bold">Apply Filters</a>
                                    </div>
                                    <!--end::Text-->
                                </div>
                            </button>
                        </h3>
                        <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <div class="card-header border-0">
                                    <div class="row mb-5">
                                        <div class="col-md-12 mt-3">
                                            <label class="fs-6 fw-semibold form-label mb-2">
                                                <span>Project</span>
                                            </label>
                                            <select name="project_name" id="project_name" aria-label="Select a Project Name" data-control="select2" data-placeholder="Select a Project Name" class="form-select form-select-solid">
                                                <option value="">Select Project</option>
                                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div class="card"> 
            <div class="card-body pt-3">
                <div class="table-responsive overflow-*">
                    <table class="table table-striped table-bordered nowrap" id="project_details">
                        <thead>
                            <tr>
                                <th>Project</th>
                                <th>Type</th>
                                <th>SOF</th>
                                <th>Provinces</th>
                                <th>Districts</th>
                                <th>Project Tenure</th>
                                <th>Actions</th>
                                <th>Extract DIP</th>
                                <th>Review Meeting</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    
    </div>

    <?php $__env->startPush("scripts"); ?>
    <script src="<?php echo e(asset("assets/plugins/custom/datatables/datatables.bundle.js")); ?>"></script>
    <script>
        var project = $('#project_details').DataTable({
            "dom": 'lfBrtip',
          
            buttons: [
                {

                    extend: 'excelHtml5',

                    filename: 'Identificatoin Data export_',

                    text: '<i class="flaticon2-download"></i> Excel',

                    title: '',

                    className: 'btn btn-outline-success',

                    exportOptions: {

                        columns: [1, 2, 3, 4, 5, 6, 7]

                    }

                },

                {

                    extend: 'csvHtml5',

                    filename: 'Identificatoin Data CSV_',

                    text: '<i class="flaticon2-download"></i> CSV',

                    title: '',

                    className: 'btn btn-outline-success',

                    exportOptions: {

                        columns: [1, 2, 3, 4, 5, 6, 7]

                    }

                }
            ],

            "processing": true,
            "serverSide": true,
            "searching": false,
            "bLengthChange": false,
            "paging": true,
            "bInfo": false,
            "responsive": false,
            "info": false,
            "ajax": {
                "url": "<?php echo e(route('admin.get_project_details')); ?>",
                "dataType": "json",
                "type": "POST",
                "data": {
                    "_token": "<?php echo csrf_token() ?>"
                }
            },
            "columns": [{
                    "data": "project",
                    "searchable": false,
                    "orderable": false,
                    "sorting": false
                },
                {
                    "data": "type",
                    "searchable": false,
                    "orderable": false
                },
                {
                    "data": "sof",
                    "searchable": false,
                    "orderable": false
                },
                {
                    "data": "province",
                    "searchable": false,
                    "orderable": false
                },
                {
                    "data": "district",
                    "searchable": false,
                    "orderable": false
                },
                {
                    "data": "project_tenure",
                    "searchable": false,
                    "orderable": false
                },
                {
                    "data": "action",
                    "searchable": false,
                    "orderable": false,
                    "render": function(data, type, row) {
                        var actionHtml = '';

                        // Conditionally render action buttons based on role or any other criteria
                        if (row.role === 'f_p') {
                            actionHtml += '<a class="btn-icon mx-1" href="<?php echo e(route('project.detail', ':id')); ?>" title="Edit Project"><i class="fas fa-pencil-alt text-warning"></i></a>';
                        }

                        if ('<?php echo e(auth()->user()->user_type); ?>' === 'admin') {
                            actionHtml += '<a class="btn-icon mx-1" href="<?php echo e(route('project.detail', ':id')); ?>" title="Edit Project"><i class="fas fa-pencil-alt text-warning"></i></a>';
                            actionHtml += '<a class="btn-icon mx-1" onclick="event.preventDefault(); del(' + row.id + ');" title="Delete Project" href="#"><i class="fas fa-trash-alt text-danger"></i></a>';
                        }

                        actionHtml += '<a class="btn-icon mx-1" href="<?php echo e(route('projects.show', ':id')); ?>" target="_blank" title="Show Project"><i class="far fa-eye text-success"></i></a>';

                        return actionHtml.replace(/:id/g, row.id);
                    }
                },
                { 
                        "data": "project_activities",
                        "searchable": false,
                        "orderable": false,
                        "render": function(data, type, row) {
                            return '<a class="btn" href="<?php echo e(route("project.view",":id")); ?>" target="_blank" title="Download project DIP"><i class="far fa-caret-square-right text-info"></i></a>'.replace(':id', row.id);
                        }
                    },
                { 
                    "data": "review_meeting",
                    "searchable": false,
                    "orderable": false,
                    "render": function(data, type, row) {
                        return '<a class="btn" href="<?php echo e(route("projectreviews.show", ":id")); ?>" title="Add/Show Review Meeting"><i class="far fa-calendar-alt text-info"></i></a>'.replace(':id', row.id);
                    }
                }
            ]
                
        });
        project.order([]);
        $("#project_name").change(function() {

            var table = $('#project_details').DataTable();
            table.destroy();

            var project = document.getElementById("project_name").value ?? '1';

            var projects = $('#project_details').DataTable({

                "dom": 'lfBrtip',
                buttons: [
                    'csv', 'excel'
                ],
                "processing": true,
                "serverSide": true,
                "searching": false,
                "bLengthChange": false,
                "paging": true,
                "bInfo": false,
                "responsive": false,
                "info": false,

                "ajax": {
                    "url": "<?php echo e(route('admin.get_project_details')); ?>",
                    "dataType": "json",
                    "type": "POST",
                    "data": {
                        "_token": "<?php echo csrf_token() ?>",
                        'project': project
                    }
                },
                "columns": [{
                        "data": "project",
                        "searchable": false,
                        "orderable": false,
                    },
                    {
                        "data": "type",
                        "searchable": false,
                        "orderable": false
                    },
                    {
                        "data": "sof",
                        "searchable": false,
                        "orderable": false
                    },
                    {
                        "data": "province",
                        "searchable": false,
                        "orderable": false
                    },
                    {
                        "data": "district",
                        "searchable": false,
                        "orderable": false
                    },
                    {
                        "data": "project_tenure",
                        "searchable": false,
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "searchable": false,
                        "orderable": false,
                        "render": function(data, type, row) {
                            var actionHtml = '';

                            // Conditionally render action buttons based on role or any other criteria
                            if (row.role === 'f_p') {
                                actionHtml += '<a class="btn-icon mx-1" href="<?php echo e(route('project.detail', ':id')); ?>" title="Edit Project"><i class="fas fa-pencil-alt text-warning"></i></a>';
                            }

                            if ('<?php echo e(auth()->user()->user_type); ?>' === 'admin') {
                                actionHtml += '<a class="btn-icon mx-1" href="<?php echo e(route('project.detail', ':id')); ?>" title="Edit Project"><i class="fas fa-pencil-alt text-warning"></i></a>';
                                actionHtml += '<a class="btn-icon mx-1" onclick="event.preventDefault(); del(' + row.id + ');" title="Delete Project" href="#"><i class="fas fa-trash-alt text-danger"></i></a>';
                            }

                            actionHtml += '<a class="btn-icon mx-1" href="<?php echo e(route('projects.show', ':id')); ?>" target="_blank" title="Show Project"><i class="far fa-eye text-success"></i></a>';

                            return actionHtml.replace(/:id/g, row.id);
                        }
                    },
                    { 
                        "data": "project_activities",
                        "searchable": false,
                        "orderable": false,
                        "render": function(data, type, row) {
                            return '<a class="btn" href="<?php echo e(route("project.view", ":id")); ?>" target="_blank" title="Download project DIP"><i class="far fa-caret-square-right text-info"></i></a>'.replace(':id', row.id);
                        }
                    },
                    { 
                        "data": "review_meeting",
                        "searchable": false,
                        "orderable": false,
                        "render": function(data, type, row) {
                            return '<a class="btn" href="<?php echo e(route("projectreviews.show", ":id")); ?>" title="Add/Show Review Meeting"><i class="far fa-calendar-alt text-info"></i></a>'.replace(':id', row.id);
                        }
                    },
                   
                ]

            });
            projects.order([]);
        });


        function del(id) {
            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Yes, delete it!"
            }).then(function(result) {
                if (result.value) {
                    Swal.fire(
                        "Deleted!",
                        "Your Project has been deleted.",
                        "success"
                    );
                    var APP_URL = <?php echo json_encode(url('/')); ?>

                    window.location.href = APP_URL + "/dip/delete/" + id;
                }
            });
        }
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e)): ?>
<?php $attributes = $__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e; ?>
<?php unset($__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e)): ?>
<?php $component = $__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e; ?>
<?php unset($__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\mis_sc\resources\views/admin/projects/projectDetail_index.blade.php ENDPATH**/ ?>