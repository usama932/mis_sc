<?php if (isset($component)) { $__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e = $attributes; } ?>
<?php $component = App\View\Components\DefaultLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('default-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DefaultLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 
    <?php $__env->startSection('title'); ?>
         Quality Benchmarks (QB's)
    <?php $__env->stopSection(); ?>
    <div class="card p-3">
        <div class="row">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit quality benchmarks')): ?>
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <a href="<?php echo e(route('action_points.edit',$action_point->id)); ?>" class="btn btn-primary me-md-2 btn-sm" target="_blank">Edit QB</a>
            </div>
            <?php endif; ?>
            <div class="col-md-6 ">
                <div class="card-title  border-0 my-4"">
                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1 " style="background-color: #F1C40F !important; border-radius:25px;">
                            <h5 class="fw-bold m-3">Detail Quality Bench::</h5>
                        </div>
                    </div>
                </div>
                <table class="table table-striped p-3">
                    <tr>
                        <td><strong>Unique Code</strong></td>
                        <td><?php echo e($action_point->qb?->assement_code ?? " "); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Date Visit</strong></td>
                        <td><?php echo e(date('d-M-Y', strtotime($action_point->qb?->date_visit)) ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Accompanied By</strong></td>
                        <td><?php echo e($action_point->qb->accompanied_by ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Type of visit</strong></td>
                        <td><?php echo e($action_point->qb?->type_of_visit ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Province</strong></td>
                        <td><?php echo e($action_point->qb?->provinces?->province_name ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>District</strong></td>
                        <td><?php echo e($action_point->qb?->districts?->district_name ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Village</strong></td>
                        <td><?php echo e($action_point->qb?->village); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Project Type</strong></td>
                        <td><?php echo e($action_point->qb?->project_type); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Project</strong></td>
                        <td><?php echo e($action_point->qb?->project->name ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Monitoring Type</strong></td>
                        <td><?php echo e($action_point->qb?->monitoring_type ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>QB's Not Applicable</strong></td>
                        <td><?php echo e($action_point->qb?->qb_not_applicable ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>QB's Fully Met</strong></td>
                        <td><?php echo e($action_point->qb?->qbs_fully_met ?? ''); ?></td>
                    </tr>	
                    <tr>
                        <td ><strong>QB's Not Fully Met</strong></td>
                        <td><?php echo e($action_point->qb?->qbs_not_fully_met ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>QB's Fully Met</strong></td>
                        <td><?php echo e($action_point->qb?->qbs_fully_met ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Score Out</strong></td>
                        <td><?php echo e($action_point->qb?->score_out ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Activity Description</strong></td>
                        <td><?php echo e($action_point->qb?->activity_description ?? ''); ?></td>
                    </tr>
                    
                    <tr>
                        <td><strong>QB Created By </strong></td>
                        <td><?php echo e($action_point->qb?->user->name ?? ""); ?></td>
                    </tr>
                    <tr>
                        <td><strong>QB Created At </strong></td>
                        <td><?php echo e(date('d-M-Y', strtotime($action_point->qb?->created_at)) ?? ""); ?></td>
                    </tr>
                
                </table>
                
            </div>
            <div class="col-md-6 ">
                <div class="card-title  border-0 my-4"">
                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1 " style="background-color: #F1C40F !important; border-radius:25px;">
                            <h5 class="fw-bold m-3">Detail QB Action Point::</h5>
                        </div>
                    </div>
                </div>
                <table class="table table-striped p-3">
                    <tr>
                        <td><strong>QB.#</strong></td>
                        <td><?php echo e($action_point->monitor_visit?->activity_number ?? " "); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Gap/Issues</strong></td>
                        <td><?php echo e($action_point->monitor_visit?->gap_issue ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Debrief Notes against identified Gap(s)</strong></td>
                        <td><?php echo e($action_point->db_note ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Action point agreed (Yes/No)</strong></td>
                        <td><?php echo e($action_point->action_agree ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Actions to make QB fully met</strong></td>
                        <td><?php echo e($action_point->qb_recommendation ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Action Type (Administrative/ Technical/ Both)</strong></td>
                        <td><?php echo e($action_point->action_type ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td ><strong>Responsible Person</strong></td>
                        <td><?php echo e($action_point->responsible_person ?? ''); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Status</strong></td>
                        <td><?php echo e($action_point->status ?? ""); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Deadline </strong></td>
                        <td><?php if($action_point->deadline != ''): ?> <?php echo e(date('d-M-Y', strtotime($action_point->deadline)) ?? ""); ?> <?php endif; ?></td>
                    </tr>
                    <tr class="col-md-3 col-sm-3 mt-5"> 
                        <td><strong>Completion Date </strong></td>
                        <td><?php if(!empty($action_point->action_achiev?->completion_date)): ?><?php echo e(date('d-M-Y', strtotime($action_point->action_achiev?->completion_date ?? " "))); ?> <?php endif; ?></td>
                    </div>
                    <tr class="col-md-3 col-sm-3 mt-5"> 
                        <td><strong>Completion Note </strong></td>
                        <td><?php echo e($action_point->action_achiev?->comments ?? " "); ?></td>
                    </tr>
                    <tr>
                        <td class="fs-7"><strong>Action Point Created By </strong></td>
                        <td><?php echo e($action_point->qb?->user->name ?? ""); ?></td>
                    </tr>
                    <tr>
                        <td class="fs-7"><strong>Action Point Created At </strong></td>
                        <td><?php echo e(date('d-M-Y', strtotime($action_point->qb?->created_at)) ?? ""); ?></td>
                    </tr>
                    <tr>
                        <td class="fs-7"><strong>Action Point Updated By </strong></td>
                        <td><?php echo e($action_point->qb?->user->name ?? ""); ?></td>
                    </tr>
                    <tr>
                        <td class="fs-7"><strong>Action Point Updated At </strong></td>
                        <td><?php echo e(date('d-M-Y', strtotime($action_point->qb?->created_at)) ?? ""); ?></td>
                    </tr>
                </table>
                
            </div>


        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e)): ?>
<?php $attributes = $__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e; ?>
<?php unset($__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e)): ?>
<?php $component = $__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e; ?>
<?php unset($__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\mis_sc\resources\views/admin/quality_bench/action_point/Qb_detail.blade.php ENDPATH**/ ?>