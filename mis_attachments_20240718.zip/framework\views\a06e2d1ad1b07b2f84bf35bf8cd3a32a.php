<!--begin::Indicator label-->
<span class="indicator-label">
    <?php echo e($label ?? 'Upgrade Plan'); ?>

</span>
<!--end::Indicator label-->
<!--begin::Indicator progress-->
<span class="indicator-progress">Please wait...
<span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
<!--end::Indicator progress-->
<?php /**PATH C:\xampp\htdocs\mis_sc\resources\views/partials/general/_button-indicator.blade.php ENDPATH**/ ?>