<?php if (isset($component)) { $__componentOriginal7d4adf92a073eb6c2876d9110358a4e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d4adf92a073eb6c2876d9110358a4e2 = $attributes; } ?>
<?php $component = App\View\Components\NformLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nform-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NformLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title'); ?>
       Add Activity Progress
    <?php $__env->stopSection(); ?>
  
    <div class="card mb-5">
        <div class="accordion" id="accordionExample">
            <div class="accordion-item">
                <h3 class="accordion-header" id="headingOne">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        <div class="d-flex align-items-center">
                            <!--begin::Symbol-->
                            <div class="symbol symbol-50px me-5">
                                <span class="symbol-label bg-light-danger">
                                    <i class="ki-duotone ki-filter-search fs-2x text-danger">
                                        <span class="path1"></span>
                                        <span class="path2"></span>
                                    </i>
                                </span>
                            </div>
                            <!--end::Symbol-->
                            <!--begin::Text-->
                            <div class="d-flex flex-column">
                                <a href="javascript:;" class="text-dark text-hover-primary fs-6 fw-bold">Apply Filters</a>
                            </div>
                            <!--end::Text-->
                        </div>
                    </button>
                </h3>
                <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        <div class="card-header border-0">
                            <div class="row mb-5">
                                <div class="col-md-12 mt-3">
                                    <label class="fs-6 fw-semibold form-label mb-2">
                                        <span>Project</span>
                                    </label>
                                    <select name="project" id="project" aria-label="Select a Project" data-control="select2" data-placeholder="Select a Project..." class="form-select" data-allow-clear="true">
                                        <option value=''>Select Project</option>
                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty($project->detail)): ?>
                                            <option value='<?php echo e($project->id); ?>'><?php echo e(ucfirst($project->name)); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
        
            <div class="table-responsive overflow-*">
                <table class="table table-striped table-bordered nowrap" id="dip_complete_activity" style="width:100%">
                    <thead>
                        <tr>
                            <th>Activity</th>
                            <th>Activity Title</th>
                            <th>Sub Theme</th>
                            <th>Activity Type</th>
                            <th>Project</th>
                            <th>LOP Target</th>
                            <th>Month</th>
                            <th>Created By</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
    
    <?php $__env->startPush("scripts"); ?>
    <script>
        $(document).ready(function () {
    function initDataTable(dipId) {
        $('#dip_complete_activity').DataTable({
            "order": [[1, 'desc']],
            "dom": 'lfBrtip',
            buttons: ['csv', 'excel'],
            "responsive": false,
            "processing": true,
            "serverSide": true,
            "searching": false,
            "bLengthChange": false,
            "bInfo": false,
            "info": true,
            "ajax": {
                "url": "<?php echo e(route('admin.get_complete_activity')); ?>",
                "dataType": "json",
                "type": "POST",
                "data": {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "dip_id": dipId
                }
            },
            "columns": [
                {"data": "activity", "searchable": false, "orderable": false},
                {"data": "activity_number", "searchable": false, "orderable": false},
                {"data": "sub_theme", "searchable": false, "orderable": false},
                {"data": "activity_type", "searchable": false, "orderable": false},
                {"data": "project", "searchable": false, "orderable": false},
                {"data": "lop_target", "searchable": false, "orderable": false},
                {"data": "quarter_target", "searchable": false, "orderable": false},
                {"data": "created_by", "searchable": false, "orderable": false},
                {"data": "created_at", "searchable": false, "orderable": false},
                {"data": "action", "searchable": false, "orderable": false}
            ]
        });
    }

    $('#project').change(function () {
        var table = $('#dip_complete_activity').DataTable();
        table.destroy();
        var dipId = $(this).val();
        initDataTable(dipId);
    });

    initDataTable($('#project').val());
});


        function del(id) {
            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Yes, delete it!"
            }).then(function(result) {
                if (result.value) {
                    Swal.fire(
                        "Deleted!",
                        "Your DIP has been deleted.",
                        "success"
                    );
                    var APP_URL = <?php echo json_encode(url('/')); ?>

                    window.location.href = APP_URL + "/activity_dips/delete/" + id;
                }
            });
        }
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d4adf92a073eb6c2876d9110358a4e2)): ?>
<?php $attributes = $__attributesOriginal7d4adf92a073eb6c2876d9110358a4e2; ?>
<?php unset($__attributesOriginal7d4adf92a073eb6c2876d9110358a4e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d4adf92a073eb6c2876d9110358a4e2)): ?>
<?php $component = $__componentOriginal7d4adf92a073eb6c2876d9110358a4e2; ?>
<?php unset($__componentOriginal7d4adf92a073eb6c2876d9110358a4e2); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\mis_sc\resources\views/admin/dip/activity_complete.blade.php ENDPATH**/ ?>