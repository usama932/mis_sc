

<?php $__env->startSection('content'); ?>

    <!--begin::App-->
    <div class="d-flex flex-column flex-root app-root" id="kt_app_root" style="background-image: linear-gradient(rgba(0, 0, 255, 0.1), rgba(0, 0, 255, 0.1)), url('<?php echo e(URL::asset('assets/media/logos/image.jpg')); ?>'); background-size: 100% 100%;">
 
       
        <div class="d-flex flex-column flex-lg-row flex-column-fluid">
            <!--begin::Body-->
            <div class="d-flex flex-column flex-lg-row-fluid w-lg-50 p-10 order-2 order-lg-1">
                <div class="" style="margin-left: auto">
                    <?php if(request()->segment(1) == 'login'): ?>
                        <div class="m-3">
                            <button class="btn btn-primary" id="staffTab">Staff Login</button>
                            <button class="btn btn-danger" id="guestTab">Guest Login</button>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="d-flex flex-center flex-column flex-lg-row-fluid">
                    <!--begin::Wrapper-->
                    <div class=" p-10">
                        <!--begin::Page-->
                        <?php echo e($slot); ?>

                        <!--end::Page-->
                    </div>
                    <!--end::Wrapper-->
                </div>
                <!--end::Form-->

             
            </div>
            <!--end::Body-->

            
        </div>
        <!--end::Wrapper-->
    </div>
    <!--end::App-->
    <?php $__env->startPush('scripts'); ?>
    
   
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            var staffTab = document.getElementById("staffTab");
            var guestTab = document.getElementById("guestTab");
            var staffTabContent = document.getElementById("staffTabcontent");
            var guestTabContent = document.getElementById("guestTabcontent");
            guestTabContent.style.display = "none";
            staffTab.style.display  = "none";
    
            staffTab.addEventListener("click", function () {
                staffTabContent.style.display = "block";
                guestTabContent.style.display = "none";
                staffTab.style.display  = "none";
                guestTab.style.display  = "block";
            });
    
            guestTab.addEventListener("click", function () {
                guestTabContent.style.display = "block";
                staffTabContent.style.display = "none";
                guestTab.style.display  = "none";
                staffTab.style.display  =  "block";
            });
        });
    </script>
     
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mis_sc\resources\views/layout/_auth.blade.php ENDPATH**/ ?>