<div class="mx-5">
    
    <div class="">
        <div class="d-flex justify-content-end hover-elevate-up mt-10 mx-5">
            <button class="btn btn-sm btn-primary mx-5" id="addactionpointBtn"> <i class="ki-duotone ki-abstract-10">
            <span class="path1"></span>
            <span class="path2"></span>
            </i>Add Action Point</button>
        </div>
    </div>

    <form class="form p-5"  id="qb_action_point_form"  novalidate="novalidate" action="<?php echo e(route('action_points.store')); ?>" method="post">  

        <input type="hidden" name="quality_bench_id" value="<?php echo e($qb->id); ?>">
        <div class="card-body ">
            <div class="card-title  border-0 my-1"">
                <div class="card-title">
                    <div class="d-flex align-items-center position-relative my-1 " style="background-color: #F1C40F !important; border-radius:25px;">
                        <h5 class="fw-bold m-3">Action Points Detail::</h5>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="fv-row col-md-12 mt-3">
                    <label class="fs-6 fw-semibold form-label mb-2">
                        <span class="required">Select Identified Gap</span>
                    </label>
                    <select name="activity_number"  <?php $__errorArgs = ['activity_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> aria-label="Select a Action Point Agree" data-control="select2" data-placeholder="Gap/Issues" class="form-select  " id="activity_id" >
                        <option value="">Select Activity Number</option>
                        <?php $__currentLoopData = $monitor_visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monitor_visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option  value="<?php echo e($monitor_visit->id); ?>"><?php echo e($monitor_visit->activity_number); ?>- <?php echo e($monitor_visit->gap_issue); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    </select>
                </div>
                <div class="fv-row col-md-8 mt-3">
                    <label class="fs-6 fw-semibold form-label mb-2">
                        <span class="required">Debrief Notes against identify Gap</span>
                    </label>
                    <textarea class="form-control "  name="db_note" ></textarea>
                </div>
                <div class="fv-row col-md-4 mt-3">
                    <label class="fs-6 fw-semibold form-label mb-2">
                        <span class="required">Action Point Agree</span>
                    </label>
                    <select   name="action_agree" id="action_agree" <?php $__errorArgs = ['action_agree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> aria-label="Select a Action Point Agree" data-control="select2" data-placeholder="Select a Action Point Agree..." class="form-select  agree_id" required>
                        <option value="">Select Action Point Agree</option>
                        <option  value="Yes">Yes</option>
                        <option  value="No">No</option>
                    </select>
                </div>
                <div class="fv-row col-md-12 mt-3 action_agree_id">
                    <label class="fs-6 fw-semibold form-label mb-2">
                        <span class="required">Actions to make QB Fully Met</span>
                    </label>
                    <textarea  class="form-control "  name="qb_recommendation" id="qb_recommendation"></textarea>
                </div>
                <div class="fv-row col-md-3 mt-3 action_agree_id">
                    <label class="fs-6 fw-semibold form-label mb-2">
                        <span class="required">Action Type</span>
                    </label>
                    <select   name="action_type" id="action_type" aria-label="Select a Action Type" data-control="select2" data-placeholder="Select a Action Type..." class="form-select">
                        <option value="">Select Action Type</option>
                        <option  value="Administrative">Administrative</option>
                        <option  value="Technical">Technical</option>
                        <option  value="Both (Technical/Administrative)">Both (Technical/Administrative)</option>
                    </select>
                </div>
                <div class="fv-row col-md-3 mt-3 action_agree_id">
                    <label class="fs-6 fw-semibold form-label mb-2">
                        <span class="required">Who is responsible?</span>
                    </label>
                    <input class="form-control" placeholder="Enter Who is Responsible" name="responsible_person" id="responsible_person" value="" >
                </div>
                <div class="fv-row col-md-3 mt-3">
                    <label class="fs-6 fw-semibold form-label mb-2">
                        <span class="required">Status</span>
                    </label>
                    <select name="status" id="status" aria-label="Select a Status" data-control="select2" data-placeholder="Select Status" class="form-select">
                        <option value="">Select Status</option>
                        <option  value="To be Acheived">To be Acheived</option>
                        <option  value="Partialy Acheived">Partialy Acheived</option>
                        <option  value="Acheived">Acheived</option>
                        <option  value="Not Acheived">Not Acheived</option>   
                    </select>
                </div>
                <div class="fv-row col-md-3 mt-3 action_agree_id deadline">
                    <label class="fs-6 fw-semibold form-label mb-2">
                        <span class="required">Deadline</span>
                    </label>
                    <input type="text"  <?php $__errorArgs = ['deadline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> name="deadline" id="deadline" placeholder="Select Deadline"  class="form-control" onkeydown="event.preventDefault()" data-provide="datepicker" value="" >
                </div>
              
            </div>
        
        
            </div>
            <div class="d-flex justify-content-end p-5">
                <button type="submit" id="kt_action_point_submit" class="btn btn-primary btn-sm ">
                    <?php echo $__env->make('partials/general/_button-indicator', ['label' => 'Submit Action Point'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </button>
                <button type="button" class="btn btn-sm btn-danger mx-2 me-5" id="cancelactionBtn" style="display: none;"> 
                    <i class="ki-duotone ki-abstract-10">
                        <span class="path1"></span>
                        <span class="path2"></span>
                    </i>Cancel
                </button>
            </div>
        </div>
    
    </form>
   
    <div class="card-body" id="actionpointtableDiv">

        <div class="card-title  border-0">
            <div class="card-title my-4">
                <div class="d-flex align-items-center position-relative my-1 " style="background-color: #F1C40F !important; border-radius:25px;">
                    <h5 class="fw-bold m-3">Action Point List</h5>
                </div>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered" id="action_points"style="margin-top: 13px !important">
                <thead>
                    <tr>
                        <th>Activity.#</th>
                        <th>Debrief Notes against identified Gap(s)</th>
                        <th>Action Agree</th>
                        <th>Actions to make QB Fully Met</th>
                        <th>Type</th>
                        <th>Responsible Person</th>
                        <th>Deadline</th>
                        <th>status</th>
                        
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
         
            </table>
        </div>
        <div class="modal fade" id="view_action_point" data-backdrop="static" tabindex="-1" role="dialog"
            aria-labelledby="staticBackdrop" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4 class="modal-title" id="view_monitor_visit">Action Point Details</h4>
                    </div>
                    <div class="modal-body"></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light-primary font-weight-bold close"
                            data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH C:\xampp\htdocs\mis_sc\resources\views/admin/quality_bench/action_point/action_point.blade.php ENDPATH**/ ?>