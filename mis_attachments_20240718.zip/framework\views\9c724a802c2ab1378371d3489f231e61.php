<div class="app-navbar flex-shrink-0">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read dip')): ?>
        <div class="app-navbar-item ms-1 ms-md-3">
            <div class="btn btn-icon btn-custom btn-icon-muted btn-active-light btn-active-color-primary w-30px h-30px w-md-40px h-md-40px" data-kt-menu-trigger="{default: 'click', lg: 'hover'}" data-kt-menu-attach="parent"
                data-kt-menu-placement="bottom-end" id="kt_menu_item_wow"><i class="fa fa-bell" aria-hidden="true" style="font-size:16px;color:red"></i></div>
            <?php echo $__env->make('partials/menus/_notifications-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php endif; ?>
	<div class="app-navbar-item ms-1 ms-md-4" id="kt_header_user_menu_toggle">
        <?php if(auth()->user()->designation == '6' || auth()->user()->designation == '5' && auth()->user()->permissions_level == 'province-wide'): ?>
            <div class="mx-5">
                <div class="btn-group">
                    <select class="form-select btn btn-sm btn-info btn-outline-info rounded-circle" id="update_province">
                        <option class="rounded-circle" value="4" <?php if(auth()->user()->province == '4'): ?> selected <?php endif; ?>>Sindh</option>
                        <option class="rounded-circle" value="2" <?php if(auth()->user()->province == '2'): ?> selected <?php endif; ?>>KPK</option>
                        <option class="rounded-circle" value="3" <?php if(auth()->user()->province == '3'): ?> selected <?php endif; ?>>Baloshistan</option>
                    </select>
                </div>
            </div>
        <?php endif; ?>
		<div class="cursor-pointer symbol symbol-35px" data-kt-menu-trigger="{default: 'click', lg: 'hover'}" data-kt-menu-attach="parent" data-kt-menu-placement="bottom-end">
            <?php if(Auth::user()?->profile_photo_url): ?>
                <img src="<?php echo e(\Auth::user()?->profile_photo_url); ?>" class="rounded-3" alt="user" />
            <?php else: ?>
                <div class="symbol-label fs-3 <?php echo e(app(\App\Actions\GetThemeType::class)->handle('bg-light-? text-?', Auth::user()?->name)); ?>">
                    <?php echo e(substr(Auth::user()?->name, 0, 1)); ?>

                </div>
            <?php endif; ?>
        </div>
        <?php echo $__env->make('partials/menus/_user-account-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\mis_sc\resources\views/layout/partials/sidebar-layout/header/_navbar.blade.php ENDPATH**/ ?>